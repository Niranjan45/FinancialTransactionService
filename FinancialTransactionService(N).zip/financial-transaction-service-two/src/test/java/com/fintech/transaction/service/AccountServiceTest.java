package com.fintech.transaction.service;

import com.fintech.transaction.dto.request.CreateAccountRequest;
import com.fintech.transaction.dto.response.AccountResponse;
import com.fintech.transaction.entity.Account;
import com.fintech.transaction.enums.AccountStatus;
import com.fintech.transaction.exception.AccountNotFoundException;
import com.fintech.transaction.exception.DuplicateAccountException;
import com.fintech.transaction.repository.AccountRepository;
import com.fintech.transaction.service.impl.AccountServiceImpl;
import com.fintech.transaction.util.AccountMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.Optional;
import java.util.UUID;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("AccountService Unit Tests")
class AccountServiceTest {

    @Mock
    private AccountRepository accountRepository;

    @Mock
    private AccountMapper accountMapper;

    @InjectMocks
    private AccountServiceImpl accountService;

    private Account sampleAccount;
    private AccountResponse sampleResponse;

    @BeforeEach
    void setUp() {
        sampleAccount = Account.builder()
                .accountId(UUID.randomUUID())
                .accountHolderName("Alice Johnson")
                .accountNumber("ACC-0000001")
                .balance(new BigDecimal("5000.00"))
                .currency("USD")
                .status(AccountStatus.ACTIVE)
                .version(0L)
                .build();

        sampleResponse = AccountResponse.builder()
                .accountId(sampleAccount.getAccountId())
                .accountHolderName("Alice Johnson")
                .accountNumber("ACC-0000001")
                .balance(new BigDecimal("5000.00"))
                .currency("USD")
                .status(AccountStatus.ACTIVE)
                .build();
    }

    // ─── createAccount ────────────────────────────────────────────────────────

    @Test
    @DisplayName("createAccount — success")
    void createAccount_success() {
        CreateAccountRequest request = new CreateAccountRequest();
        request.setAccountHolderName("Alice Johnson");
        request.setAccountNumber("ACC-0000001");
        request.setInitialBalance(new BigDecimal("5000.00"));
        request.setCurrency("USD");

        when(accountRepository.existsByAccountNumber("ACC-0000001")).thenReturn(false);
        when(accountRepository.save(any(Account.class))).thenReturn(sampleAccount);
        when(accountMapper.toResponse(sampleAccount)).thenReturn(sampleResponse);

        AccountResponse result = accountService.createAccount(request);

        assertThat(result).isNotNull();
        assertThat(result.getAccountNumber()).isEqualTo("ACC-0000001");
        assertThat(result.getBalance()).isEqualByComparingTo("5000.00");
        verify(accountRepository).save(any(Account.class));
    }

    @Test
    @DisplayName("createAccount — duplicate account number throws DuplicateAccountException")
    void createAccount_duplicateNumber_throwsException() {
        CreateAccountRequest request = new CreateAccountRequest();
        request.setAccountNumber("ACC-0000001");
        request.setInitialBalance(BigDecimal.ZERO);
        request.setCurrency("USD");
        request.setAccountHolderName("Test");

        when(accountRepository.existsByAccountNumber("ACC-0000001")).thenReturn(true);

        assertThatThrownBy(() -> accountService.createAccount(request))
                .isInstanceOf(DuplicateAccountException.class)
                .hasMessageContaining("ACC-0000001");

        verify(accountRepository, never()).save(any());
    }

    // ─── getAccountById ───────────────────────────────────────────────────────

    @Test
    @DisplayName("getAccountById — found returns response")
    void getAccountById_found() {
        UUID id = sampleAccount.getAccountId();
        when(accountRepository.findById(id)).thenReturn(Optional.of(sampleAccount));
        when(accountMapper.toResponse(sampleAccount)).thenReturn(sampleResponse);

        AccountResponse result = accountService.getAccountById(id);

        assertThat(result.getAccountId()).isEqualTo(id);
    }

    @Test
    @DisplayName("getAccountById — not found throws AccountNotFoundException")
    void getAccountById_notFound() {
        UUID id = UUID.randomUUID();
        when(accountRepository.findById(id)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> accountService.getAccountById(id))
                .isInstanceOf(AccountNotFoundException.class);
    }
}
