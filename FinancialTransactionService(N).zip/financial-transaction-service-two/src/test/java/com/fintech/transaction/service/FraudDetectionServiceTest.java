package com.fintech.transaction.service;

import com.fintech.transaction.entity.FraudRule;
import com.fintech.transaction.exception.FraudDetectedException;
import com.fintech.transaction.repository.FraudRuleRepository;
import com.fintech.transaction.repository.TransactionRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("FraudDetectionService Unit Tests")
class FraudDetectionServiceTest {

    @Mock private FraudRuleRepository  fraudRuleRepository;
    @Mock private TransactionRepository transactionRepository;

    @InjectMocks
    private FraudDetectionService fraudDetectionService;

    private UUID accountId;

    @BeforeEach
    void setUp() {
        accountId = UUID.randomUUID();
    }

    @Test
    @DisplayName("evaluate — all rules pass for normal transaction")
    void evaluate_allRulesPass() {
        FraudRule amountRule = FraudRule.builder()
                .ruleName("SINGLE_TXN_LIMIT")
                .maxAmountLimit(new BigDecimal("10000.00"))
                .enabled(true)
                .build();

        when(fraudRuleRepository.findByEnabledTrue()).thenReturn(List.of(amountRule));
        when(transactionRepository.countDailyTransactions(eq(accountId), any(LocalDateTime.class)))
                .thenReturn(2L);
        when(transactionRepository.sumDailyTransactionVolume(eq(accountId), any(LocalDateTime.class)))
                .thenReturn(new BigDecimal("1000.00"));

        // Should not throw
        assertThatCode(() -> fraudDetectionService.evaluate(accountId, new BigDecimal("500.00")))
                .doesNotThrowAnyException();
    }

    @Test
    @DisplayName("evaluate — amount exceeds single transaction limit triggers fraud")
    void evaluate_exceedsAmountLimit() {
        FraudRule amountRule = FraudRule.builder()
                .ruleName("SINGLE_TXN_LIMIT")
                .maxAmountLimit(new BigDecimal("10000.00"))
                .enabled(true)
                .build();

        when(fraudRuleRepository.findByEnabledTrue()).thenReturn(List.of(amountRule));
        when(transactionRepository.countDailyTransactions(any(), any())).thenReturn(0L);
        when(transactionRepository.sumDailyTransactionVolume(any(), any()))
                .thenReturn(BigDecimal.ZERO);

        assertThatThrownBy(() ->
                fraudDetectionService.evaluate(accountId, new BigDecimal("15000.00")))
                .isInstanceOf(FraudDetectedException.class)
                .hasMessageContaining("SINGLE_TXN_LIMIT");
    }

    @Test
    @DisplayName("evaluate — daily count limit reached triggers fraud")
    void evaluate_exceedsDailyCount() {
        FraudRule countRule = FraudRule.builder()
                .ruleName("DAILY_TXN_COUNT_LIMIT")
                .maxDailyTxnCount(10)
                .enabled(true)
                .build();

        when(fraudRuleRepository.findByEnabledTrue()).thenReturn(List.of(countRule));
        when(transactionRepository.countDailyTransactions(eq(accountId), any(LocalDateTime.class)))
                .thenReturn(10L);
        when(transactionRepository.sumDailyTransactionVolume(any(), any()))
                .thenReturn(BigDecimal.ZERO);

        assertThatThrownBy(() ->
                fraudDetectionService.evaluate(accountId, new BigDecimal("100.00")))
                .isInstanceOf(FraudDetectedException.class)
                .hasMessageContaining("DAILY_TXN_COUNT_LIMIT");
    }

    @Test
    @DisplayName("evaluate — no enabled rules always passes")
    void evaluate_noEnabledRules() {
        when(fraudRuleRepository.findByEnabledTrue()).thenReturn(List.of());
        when(transactionRepository.countDailyTransactions(any(), any())).thenReturn(0L);
        when(transactionRepository.sumDailyTransactionVolume(any(), any()))
                .thenReturn(BigDecimal.ZERO);

        assertThatCode(() ->
                fraudDetectionService.evaluate(accountId, new BigDecimal("999999.00")))
                .doesNotThrowAnyException();
    }
}
