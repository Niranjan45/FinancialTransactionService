package com.fintech.transaction.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.fintech.transaction.dto.request.DebitRequest;
import com.fintech.transaction.dto.request.TransferRequest;
import com.fintech.transaction.dto.response.TransactionResponse;
import com.fintech.transaction.entity.Account;
import com.fintech.transaction.entity.Transaction;
import com.fintech.transaction.enums.AccountStatus;
import com.fintech.transaction.enums.TransactionStatus;
import com.fintech.transaction.enums.TransactionType;
import com.fintech.transaction.exception.AccountInactiveException;
import com.fintech.transaction.exception.FraudDetectedException;
import com.fintech.transaction.exception.InsufficientBalanceException;
import com.fintech.transaction.repository.AccountRepository;
import com.fintech.transaction.repository.TransactionRepository;
import com.fintech.transaction.service.impl.TransactionServiceImpl;
import com.fintech.transaction.util.TransactionMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.Optional;
import java.util.UUID;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("TransactionService Unit Tests")
class TransactionServiceTest {

    @Mock private TransactionRepository    transactionRepository;
    @Mock private AccountRepository        accountRepository;
    @Mock private FraudDetectionService    fraudService;
    @Mock private AuditService             auditService;
    @Mock private IdempotencyService       idempotencyService;
    @Mock private TransactionEventPublisher eventPublisher;
    @Mock private AccountService           accountService;

    @Spy  private TransactionMapper transactionMapper = new TransactionMapper();
    @Spy  private ObjectMapper objectMapper = buildObjectMapper();

    @InjectMocks
    private TransactionServiceImpl transactionService;

    private Account activeAccount;
    private Account inactiveAccount;
    private Transaction savedTxn;

    @BeforeEach
    void setUp() {
        activeAccount = Account.builder()
                .accountId(UUID.randomUUID())
                .accountNumber("ACC-0000001")
                .accountHolderName("Alice")
                .balance(new BigDecimal("10000.00"))
                .currency("USD")
                .status(AccountStatus.ACTIVE)
                .version(0L)
                .build();

        inactiveAccount = Account.builder()
                .accountId(UUID.randomUUID())
                .accountNumber("ACC-0000002")
                .accountHolderName("Bob")
                .balance(new BigDecimal("5000.00"))
                .currency("USD")
                .status(AccountStatus.INACTIVE)
                .version(0L)
                .build();

        savedTxn = Transaction.builder()
                .transactionId(UUID.randomUUID())
                .fromAccount(activeAccount)
                .amount(new BigDecimal("500.00"))
                .currency("USD")
                .type(TransactionType.DEBIT)
                .status(TransactionStatus.SUCCESS)
                .retryCount(0)
                .build();
    }

    // ─── DEBIT ────────────────────────────────────────────────────────────────

    @Test
    @DisplayName("debit — success debits account balance")
    void debit_success() {
        DebitRequest request = buildDebitRequest("500.00", activeAccount.getAccountId());

        when(idempotencyService.findCachedResponse(any())).thenReturn(Optional.empty());
        when(accountRepository.findByIdWithLock(activeAccount.getAccountId()))
                .thenReturn(Optional.of(activeAccount));
        doNothing().when(fraudService).evaluate(any(), any());
        when(transactionRepository.save(any())).thenReturn(savedTxn);
        when(accountRepository.save(any())).thenReturn(activeAccount);

        TransactionResponse result = transactionService.debit(request);

        assertThat(result).isNotNull();
        assertThat(result.getStatus()).isEqualTo(TransactionStatus.SUCCESS);
        // Balance should be reduced
        assertThat(activeAccount.getBalance()).isEqualByComparingTo("9500.00");
        verify(transactionRepository, times(2)).save(any()); // initial + status update
    }

    @Test
    @DisplayName("debit — insufficient balance throws InsufficientBalanceException")
    void debit_insufficientBalance() {
        DebitRequest request = buildDebitRequest("99999.00", activeAccount.getAccountId());

        when(idempotencyService.findCachedResponse(any())).thenReturn(Optional.empty());
        when(accountRepository.findByIdWithLock(activeAccount.getAccountId()))
                .thenReturn(Optional.of(activeAccount));
        doNothing().when(fraudService).evaluate(any(), any());

        assertThatThrownBy(() -> transactionService.debit(request))
                .isInstanceOf(InsufficientBalanceException.class);

        verify(transactionRepository, never()).save(any());
    }

    @Test
    @DisplayName("debit — fraud rule triggered throws FraudDetectedException")
    void debit_fraudDetected() {
        DebitRequest request = buildDebitRequest("500.00", activeAccount.getAccountId());

        when(idempotencyService.findCachedResponse(any())).thenReturn(Optional.empty());
        when(accountRepository.findByIdWithLock(activeAccount.getAccountId()))
                .thenReturn(Optional.of(activeAccount));
        doThrow(new FraudDetectedException("Amount exceeds limit"))
                .when(fraudService).evaluate(any(), any());

        assertThatThrownBy(() -> transactionService.debit(request))
                .isInstanceOf(FraudDetectedException.class)
                .hasMessageContaining("Amount exceeds limit");
    }

    @Test
    @DisplayName("debit — inactive account throws AccountInactiveException")
    void debit_inactiveAccount() {
        DebitRequest request = buildDebitRequest("500.00", inactiveAccount.getAccountId());

        when(idempotencyService.findCachedResponse(any())).thenReturn(Optional.empty());
        when(accountRepository.findByIdWithLock(inactiveAccount.getAccountId()))
                .thenReturn(Optional.of(inactiveAccount));

        assertThatThrownBy(() -> transactionService.debit(request))
                .isInstanceOf(AccountInactiveException.class);
    }

    @Test
    @DisplayName("debit — idempotency hit returns cached response without re-processing")
    void debit_idempotencyHit() throws Exception {
        DebitRequest request = buildDebitRequest("500.00", activeAccount.getAccountId());
        TransactionResponse cached = TransactionResponse.builder()
                .transactionId(UUID.randomUUID())
                .status(TransactionStatus.SUCCESS)
                .amount(new BigDecimal("500.00"))
                .type(TransactionType.DEBIT)
                .build();

        when(idempotencyService.findCachedResponse(request.getIdempotencyKey()))
                .thenReturn(Optional.of(objectMapper.writeValueAsString(cached)));

        TransactionResponse result = transactionService.debit(request);

        assertThat(result.getStatus()).isEqualTo(TransactionStatus.SUCCESS);
        verify(accountRepository, never()).findByIdWithLock(any());
    }

    // ─── TRANSFER ─────────────────────────────────────────────────────────────

    @Test
    @DisplayName("transfer — same account throws IllegalArgumentException")
    void transfer_sameAccount_throws() {
        TransferRequest request = new TransferRequest();
        UUID id = activeAccount.getAccountId();
        request.setFromAccountId(id);
        request.setToAccountId(id);
        request.setAmount(new BigDecimal("100.00"));
        request.setCurrency("USD");
        request.setIdempotencyKey(UUID.randomUUID().toString());

        when(idempotencyService.findCachedResponse(any())).thenReturn(Optional.empty());

        assertThatThrownBy(() -> transactionService.transfer(request))
                .isInstanceOf(IllegalArgumentException.class);
    }

    // ─── Helpers ──────────────────────────────────────────────────────────────

    private DebitRequest buildDebitRequest(String amount, UUID accountId) {
        DebitRequest r = new DebitRequest();
        r.setAccountId(accountId);
        r.setAmount(new BigDecimal(amount));
        r.setCurrency("USD");
        r.setIdempotencyKey(UUID.randomUUID().toString());
        r.setDescription("Test debit");
        return r;
    }

    private static ObjectMapper buildObjectMapper() {
        ObjectMapper m = new ObjectMapper();
        m.registerModule(new JavaTimeModule());
        m.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
        return m;
    }
}
