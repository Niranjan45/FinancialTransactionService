package com.fintech.transaction.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fintech.transaction.dto.request.CreateAccountRequest;
import com.fintech.transaction.dto.response.AccountResponse;
import com.fintech.transaction.dto.response.ApiResponse;
import com.fintech.transaction.enums.AccountStatus;
import com.fintech.transaction.service.AccountService;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.math.BigDecimal;
import java.util.UUID;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(AccountController.class)
@DisplayName("AccountController Integration Tests")
class AccountControllerTest {

    @Autowired MockMvc mockMvc;
    @Autowired ObjectMapper objectMapper;

    @MockBean AccountService accountService;

    @Test
    @DisplayName("POST /api/v1/accounts — 201 Created on valid input")
    void createAccount_returns201() throws Exception {
        CreateAccountRequest request = new CreateAccountRequest();
        request.setAccountHolderName("Alice Johnson");
        request.setAccountNumber("ACC-0000001");
        request.setInitialBalance(new BigDecimal("5000.00"));
        request.setCurrency("USD");

        AccountResponse response = AccountResponse.builder()
                .accountId(UUID.randomUUID())
                .accountHolderName("Alice Johnson")
                .accountNumber("ACC-0000001")
                .balance(new BigDecimal("5000.00"))
                .currency("USD")
                .status(AccountStatus.ACTIVE)
                .build();

        when(accountService.createAccount(any())).thenReturn(response);

        mockMvc.perform(post("/api/v1/accounts")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.data.accountNumber").value("ACC-0000001"))
                .andExpect(jsonPath("$.data.balance").value(5000.00));
    }

    @Test
    @DisplayName("POST /api/v1/accounts — 400 Bad Request on blank holder name")
    void createAccount_validationFails() throws Exception {
        CreateAccountRequest request = new CreateAccountRequest();
        request.setAccountHolderName("");           // invalid
        request.setAccountNumber("ACC-0000001");
        request.setInitialBalance(new BigDecimal("100.00"));
        request.setCurrency("USD");

        mockMvc.perform(post("/api/v1/accounts")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.success").value(false))
                .andExpect(jsonPath("$.errorCode").value("VALIDATION_ERROR"));
    }

    @Test
    @DisplayName("GET /api/v1/accounts/{id} — 200 OK when account exists")
    void getAccount_found() throws Exception {
        UUID id = UUID.randomUUID();
        AccountResponse response = AccountResponse.builder()
                .accountId(id)
                .accountHolderName("Alice Johnson")
                .accountNumber("ACC-0000001")
                .balance(BigDecimal.TEN)
                .currency("USD")
                .status(AccountStatus.ACTIVE)
                .build();

        when(accountService.getAccountById(id)).thenReturn(response);

        mockMvc.perform(get("/api/v1/accounts/{id}", id))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.accountId").value(id.toString()));
    }
}
