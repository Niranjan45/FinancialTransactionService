-- ============================================================
-- V1__init_schema.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS accounts (
    account_id      UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
    account_holder_name VARCHAR(100) NOT NULL,
    account_number  VARCHAR(20)     NOT NULL UNIQUE,
    balance         NUMERIC(19,4)   NOT NULL DEFAULT 0.0000,
    currency        VARCHAR(3)      NOT NULL DEFAULT 'USD',
    status          VARCHAR(20)     NOT NULL DEFAULT 'ACTIVE',
    created_at      TIMESTAMP       NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMP       NOT NULL DEFAULT NOW(),
    version         BIGINT          NOT NULL DEFAULT 0,
    CONSTRAINT chk_balance_non_negative CHECK (balance >= 0),
    CONSTRAINT chk_account_status CHECK (status IN ('ACTIVE','INACTIVE','SUSPENDED','CLOSED'))
);

CREATE TABLE IF NOT EXISTS transactions (
    transaction_id  UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
    idempotency_key VARCHAR(100)    UNIQUE,
    from_account_id UUID,
    to_account_id   UUID,
    amount          NUMERIC(19,4)   NOT NULL,
    currency        VARCHAR(3)      NOT NULL DEFAULT 'USD',
    type            VARCHAR(20)     NOT NULL,
    status          VARCHAR(20)     NOT NULL DEFAULT 'INITIATED',
    description     VARCHAR(255),
    failure_reason  VARCHAR(500),
    retry_count     INT             NOT NULL DEFAULT 0,
    created_at      TIMESTAMP       NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMP       NOT NULL DEFAULT NOW(),
    CONSTRAINT fk_from_account FOREIGN KEY (from_account_id) REFERENCES accounts(account_id),
    CONSTRAINT fk_to_account   FOREIGN KEY (to_account_id)   REFERENCES accounts(account_id),
    CONSTRAINT chk_txn_status  CHECK (status IN ('INITIATED','PROCESSING','SUCCESS','FAILED','REVERSED')),
    CONSTRAINT chk_txn_type    CHECK (type IN ('DEBIT','CREDIT','TRANSFER'))
);

CREATE TABLE IF NOT EXISTS transaction_audit (
    audit_id        UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
    transaction_id  UUID            NOT NULL,
    event_type      VARCHAR(50)     NOT NULL,
    message         TEXT,
    performed_by    VARCHAR(100)    DEFAULT 'SYSTEM',
    created_at      TIMESTAMP       NOT NULL DEFAULT NOW(),
    CONSTRAINT fk_audit_txn FOREIGN KEY (transaction_id) REFERENCES transactions(transaction_id)
);

CREATE TABLE IF NOT EXISTS fraud_rules (
    rule_id         UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
    rule_name       VARCHAR(100)    NOT NULL UNIQUE,
    max_amount_limit NUMERIC(19,4),
    min_amount_limit NUMERIC(19,4),
    max_daily_txn_count INT,
    max_daily_txn_volume NUMERIC(19,4),
    enabled         BOOLEAN         NOT NULL DEFAULT TRUE,
    created_at      TIMESTAMP       NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMP       NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS idempotency_records (
    idempotency_key VARCHAR(100)    PRIMARY KEY,
    response_body   TEXT,
    status_code     INT,
    created_at      TIMESTAMP       NOT NULL DEFAULT NOW(),
    expires_at      TIMESTAMP       NOT NULL
);

-- Indexes
CREATE INDEX idx_transactions_from_account ON transactions(from_account_id);
CREATE INDEX idx_transactions_to_account   ON transactions(to_account_id);
CREATE INDEX idx_transactions_status       ON transactions(status);
CREATE INDEX idx_transactions_created_at   ON transactions(created_at);
CREATE INDEX idx_audit_transaction_id      ON transaction_audit(transaction_id);
CREATE INDEX idx_idempotency_expires_at    ON idempotency_records(expires_at);
