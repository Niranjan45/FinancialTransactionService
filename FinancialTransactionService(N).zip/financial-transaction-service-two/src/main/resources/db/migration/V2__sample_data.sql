-- ============================================================
-- V2__sample_data.sql
-- ============================================================

INSERT INTO accounts (account_id, account_holder_name, account_number, balance, currency, status)
VALUES
  ('a1000000-0000-0000-0000-000000000001', 'Alice Johnson',  'ACC-0000001', 50000.0000, 'USD', 'ACTIVE'),
  ('a1000000-0000-0000-0000-000000000002', 'Bob Williams',   'ACC-0000002', 30000.0000, 'USD', 'ACTIVE'),
  ('a1000000-0000-0000-0000-000000000003', 'Carol Martinez', 'ACC-0000003', 10000.0000, 'USD', 'ACTIVE'),
  ('a1000000-0000-0000-0000-000000000004', 'David Lee',      'ACC-0000004',  5000.0000, 'USD', 'INACTIVE');

INSERT INTO fraud_rules (rule_id, rule_name, max_amount_limit, max_daily_txn_count, max_daily_txn_volume, enabled)
VALUES
  ('f1000000-0000-0000-0000-000000000001', 'SINGLE_TXN_LIMIT',      10000.00, NULL,  NULL,      TRUE),
  ('f1000000-0000-0000-0000-000000000002', 'DAILY_TXN_COUNT_LIMIT',  NULL,     10,    NULL,      TRUE),
  ('f1000000-0000-0000-0000-000000000003', 'DAILY_VOLUME_LIMIT',     NULL,     NULL,  50000.00,  TRUE);
