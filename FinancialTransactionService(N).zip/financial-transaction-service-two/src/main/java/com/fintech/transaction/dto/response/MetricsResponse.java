package com.fintech.transaction.dto.response;

import lombok.Builder;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Map;

@Data
@Builder
public class MetricsResponse {
    private long totalTransactions;
    private Map<String, Long> transactionsByStatus;
    private BigDecimal totalSuccessfulVolume;
    private long totalAccounts;
    private long activeAccounts;
}
