package com.fintech.transaction.enums;

public enum TransactionType {
    DEBIT,
    CREDIT,
    TRANSFER
}
