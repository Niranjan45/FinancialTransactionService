package com.fintech.transaction.controller;

import com.fintech.transaction.dto.request.CreditRequest;
import com.fintech.transaction.dto.request.DebitRequest;
import com.fintech.transaction.dto.request.TransactionFilterRequest;
import com.fintech.transaction.dto.request.TransferRequest;
import com.fintech.transaction.dto.response.ApiResponse;
import com.fintech.transaction.dto.response.MetricsResponse;
import com.fintech.transaction.dto.response.TransactionResponse;
import com.fintech.transaction.service.TransactionService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequestMapping("/api/v1/transactions")
@RequiredArgsConstructor
@Tag(name = "Transaction Processing", description = "APIs for processing financial transactions")
public class TransactionController {

    private final TransactionService transactionService;

    @PostMapping("/debit")
    @Operation(summary = "Debit money from an account",
               description = "Idempotent — pass unique Idempotency-Key per operation")
    public ResponseEntity<ApiResponse<TransactionResponse>> debit(
            @Valid @RequestBody DebitRequest request) {
        TransactionResponse response = transactionService.debit(request);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.ok("Debit transaction processed", response));
    }

    @PostMapping("/credit")
    @Operation(summary = "Credit money to an account")
    public ResponseEntity<ApiResponse<TransactionResponse>> credit(
            @Valid @RequestBody CreditRequest request) {
        TransactionResponse response = transactionService.credit(request);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.ok("Credit transaction processed", response));
    }

    @PostMapping("/transfer")
    @Operation(summary = "Transfer money between accounts")
    public ResponseEntity<ApiResponse<TransactionResponse>> transfer(
            @Valid @RequestBody TransferRequest request) {
        TransactionResponse response = transactionService.transfer(request);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.ok("Transfer transaction processed", response));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Fetch transaction status by ID")
    public ResponseEntity<ApiResponse<TransactionResponse>> getTransaction(
            @Parameter(description = "Transaction UUID") @PathVariable UUID id) {
        TransactionResponse response = transactionService.getTransaction(id);
        return ResponseEntity.ok(ApiResponse.ok(response));
    }

    @GetMapping("/history")
    @Operation(summary = "List transactions with pagination and filters",
               description = "Filter by accountId, status, type, date range. Supports pagination and sorting.")
    public ResponseEntity<ApiResponse<Page<TransactionResponse>>> listTransactions(
            @ModelAttribute TransactionFilterRequest filter) {
        Page<TransactionResponse> page = transactionService.listTransactions(filter);
        return ResponseEntity.ok(ApiResponse.ok(page));
    }

    @GetMapping("/metrics")
    @Operation(summary = "Get transaction metrics dashboard")
    public ResponseEntity<ApiResponse<MetricsResponse>> getMetrics() {
        MetricsResponse metrics = transactionService.getMetrics();
        return ResponseEntity.ok(ApiResponse.ok(metrics));
    }
}
