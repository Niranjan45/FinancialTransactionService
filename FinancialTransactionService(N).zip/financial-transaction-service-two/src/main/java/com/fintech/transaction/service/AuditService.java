package com.fintech.transaction.service;

import com.fintech.transaction.entity.TransactionAudit;
import com.fintech.transaction.enums.AuditEventType;
import com.fintech.transaction.repository.TransactionAuditRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.UUID;

@Service
@RequiredArgsConstructor
@Slf4j
public class AuditService {

    private final TransactionAuditRepository auditRepository;

    /**
     * Log an audit event. Uses REQUIRES_NEW so that audits are always persisted
     * even if the outer transaction rolls back (e.g. fraud failures).
     */
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void log(UUID transactionId, AuditEventType eventType, String message) {
        TransactionAudit audit = TransactionAudit.builder()
                .transactionId(transactionId)
                .eventType(eventType)
                .message(message)
                .performedBy("SYSTEM")
                .build();
        auditRepository.save(audit);
        log.debug("Audit [{}] saved for txn={}", eventType, transactionId);
    }

    @Async
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void logAsync(UUID transactionId, AuditEventType eventType, String message) {
        log(transactionId, eventType, message);
    }
}
