package com.fintech.transaction.service;

import com.fintech.transaction.dto.request.CreditRequest;
import com.fintech.transaction.dto.request.DebitRequest;
import com.fintech.transaction.dto.request.TransactionFilterRequest;
import com.fintech.transaction.dto.request.TransferRequest;
import com.fintech.transaction.dto.response.MetricsResponse;
import com.fintech.transaction.dto.response.TransactionResponse;
import org.springframework.data.domain.Page;

import java.util.UUID;

public interface TransactionService {

    TransactionResponse debit(DebitRequest request);

    TransactionResponse credit(CreditRequest request);

    TransactionResponse transfer(TransferRequest request);

    TransactionResponse getTransaction(UUID transactionId);

    Page<TransactionResponse> listTransactions(TransactionFilterRequest filter);

    MetricsResponse getMetrics();
}
