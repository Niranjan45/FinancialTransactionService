package com.fintech.transaction.service.impl;

import com.fintech.transaction.dto.request.CreateAccountRequest;
import com.fintech.transaction.dto.response.AccountResponse;
import com.fintech.transaction.entity.Account;
import com.fintech.transaction.enums.AccountStatus;
import com.fintech.transaction.exception.AccountNotFoundException;
import com.fintech.transaction.exception.DuplicateAccountException;
import com.fintech.transaction.repository.AccountRepository;
import com.fintech.transaction.service.AccountService;
import com.fintech.transaction.util.AccountMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.UUID;

@Service
@RequiredArgsConstructor
@Slf4j
public class AccountServiceImpl implements AccountService {

    private final AccountRepository accountRepository;
    private final AccountMapper accountMapper;

    @Override
    @Transactional
    public AccountResponse createAccount(CreateAccountRequest request) {
        if (accountRepository.existsByAccountNumber(request.getAccountNumber())) {
            throw new DuplicateAccountException(
                    "Account number already exists: " + request.getAccountNumber());
        }

        Account account = Account.builder()
                .accountHolderName(request.getAccountHolderName())
                .accountNumber(request.getAccountNumber())
                .balance(request.getInitialBalance())
                .currency(request.getCurrency())
                .status(AccountStatus.ACTIVE)
                .build();

        account = accountRepository.save(account);
        log.info("Created account [{}] for holder [{}]",
                account.getAccountId(), account.getAccountHolderName());
        return accountMapper.toResponse(account);
    }

    @Override
    @Cacheable(value = "accounts", key = "#id")
    @Transactional(readOnly = true)
    public AccountResponse getAccountById(UUID id) {
        Account account = accountRepository.findById(id)
                .orElseThrow(() -> new AccountNotFoundException("Account not found: " + id));
        return accountMapper.toResponse(account);
    }

    @Override
    @CacheEvict(value = "accounts", key = "#id")
    public void evictAccountCache(UUID id) {
        log.debug("Evicted account cache for id={}", id);
    }
}
