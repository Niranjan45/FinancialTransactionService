package com.fintech.transaction.scheduler;

import com.fintech.transaction.entity.Transaction;
import com.fintech.transaction.enums.AuditEventType;
import com.fintech.transaction.enums.TransactionStatus;
import com.fintech.transaction.repository.AccountRepository;
import com.fintech.transaction.repository.TransactionRepository;
import com.fintech.transaction.service.AuditService;
import com.fintech.transaction.service.IdempotencyService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;

@Component
@RequiredArgsConstructor
@Slf4j
public class ReconciliationScheduler {

    private final TransactionRepository transactionRepository;
    private final AccountRepository     accountRepository;
    private final AuditService          auditService;
    private final IdempotencyService    idempotencyService;

    @Value("${transaction.retry.max-attempts:3}")
    private int maxRetryAttempts;

    /**
     * Daily reconciliation — runs at 01:00 every night.
     * Verifies that total account balances equal sum of credits minus debits.
     */
    @Scheduled(cron = "${scheduler.reconciliation.cron}")
    @Transactional(readOnly = true)
    public void runDailyReconciliation() {
        log.info("=== Starting daily reconciliation ===");

        BigDecimal totalBalance = accountRepository.findAll().stream()
                .map(a -> a.getBalance())
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        BigDecimal successfulVolume = transactionRepository.totalSuccessfulVolume();

        log.info("Reconciliation summary — Total account balances: {}, Total processed volume: {}",
                totalBalance, successfulVolume);

        // Log a global reconciliation audit record (use a synthetic fixed UUID for daily job)
        auditService.log(
                java.util.UUID.fromString("00000000-0000-0000-0000-000000000000"),
                AuditEventType.RECONCILIATION_CHECKED,
                String.format("Daily reconciliation: total_balance=%s, successful_volume=%s",
                        totalBalance, successfulVolume));

        log.info("=== Daily reconciliation complete ===");
    }

    /**
     * Retry failed transactions every 2 hours.
     * Only retries transactions that haven't exceeded max retry count.
     */
    @Scheduled(fixedDelayString = "${transaction.retry.delay-ms:7200000}")
    @Transactional
    public void retryFailedTransactions() {
        List<Transaction> retryable = transactionRepository.findRetryableTransactions(maxRetryAttempts);
        if (retryable.isEmpty()) return;

        log.info("Found {} transaction(s) eligible for retry", retryable.size());

        for (Transaction txn : retryable) {
            try {
                txn.setRetryCount(txn.getRetryCount() + 1);
                txn.setStatus(TransactionStatus.PROCESSING);
                transactionRepository.save(txn);

                auditService.log(txn.getTransactionId(), AuditEventType.RETRY_ATTEMPTED,
                        "Retry attempt #" + txn.getRetryCount());

                log.info("Queued txn={} for retry attempt #{}", txn.getTransactionId(), txn.getRetryCount());
                // In a real system this would re-enqueue to a processing queue/Kafka topic
            } catch (Exception e) {
                log.error("Failed to schedule retry for txn={}: {}", txn.getTransactionId(), e.getMessage());
            }
        }
    }

    /**
     * Cleanup expired idempotency records — runs every hour.
     */
    @Scheduled(fixedRate = 3_600_000)
    @Transactional
    public void cleanupIdempotencyRecords() {
        int deleted = idempotencyService.cleanupExpired();
        if (deleted > 0) {
            log.info("Idempotency cleanup removed {} expired records", deleted);
        }
    }
}
