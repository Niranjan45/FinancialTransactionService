package com.fintech.transaction.exception;
public class AccountInactiveException extends RuntimeException {
    public AccountInactiveException(String message) { super(message); }
}
