package com.fintech.transaction.repository;

import com.fintech.transaction.entity.Transaction;
import com.fintech.transaction.enums.TransactionStatus;
import com.fintech.transaction.enums.TransactionType;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface TransactionRepository extends JpaRepository<Transaction, UUID> {

    Optional<Transaction> findByIdempotencyKey(String idempotencyKey);

    @Query("""
        SELECT t FROM Transaction t
        WHERE (:accountId IS NULL OR t.fromAccount.accountId = :accountId OR t.toAccount.accountId = :accountId)
          AND (:status    IS NULL OR t.status = :status)
          AND (:type      IS NULL OR t.type   = :type)
          AND (:from      IS NULL OR t.createdAt >= :from)
          AND (:to        IS NULL OR t.createdAt <= :to)
        ORDER BY t.createdAt DESC
        """)
    Page<Transaction> findAllWithFilters(
            @Param("accountId") UUID accountId,
            @Param("status")    TransactionStatus status,
            @Param("type")      TransactionType type,
            @Param("from")      LocalDateTime from,
            @Param("to")        LocalDateTime to,
            Pageable pageable);

    /** Daily txn count for fraud check */
    @Query("""
        SELECT COUNT(t) FROM Transaction t
        WHERE (t.fromAccount.accountId = :accountId OR t.toAccount.accountId = :accountId)
          AND t.createdAt >= :startOfDay
          AND t.status = 'SUCCESS'
        """)
    long countDailyTransactions(@Param("accountId") UUID accountId,
                                @Param("startOfDay") LocalDateTime startOfDay);

    /** Daily volume for fraud check */
    @Query("""
        SELECT COALESCE(SUM(t.amount), 0) FROM Transaction t
        WHERE (t.fromAccount.accountId = :accountId OR t.toAccount.accountId = :accountId)
          AND t.createdAt >= :startOfDay
          AND t.status = 'SUCCESS'
        """)
    BigDecimal sumDailyTransactionVolume(@Param("accountId") UUID accountId,
                                         @Param("startOfDay") LocalDateTime startOfDay);

    /** Failed transactions eligible for retry */
    @Query("""
        SELECT t FROM Transaction t
        WHERE t.status = 'FAILED'
          AND t.retryCount < :maxRetries
        """)
    List<Transaction> findRetryableTransactions(@Param("maxRetries") int maxRetries);

    /** Metrics — total transactions by status */
    @Query("SELECT t.status, COUNT(t) FROM Transaction t GROUP BY t.status")
    List<Object[]> countByStatus();

    /** Metrics — total volume processed */
    @Query("SELECT COALESCE(SUM(t.amount), 0) FROM Transaction t WHERE t.status = 'SUCCESS'")
    BigDecimal totalSuccessfulVolume();
}
