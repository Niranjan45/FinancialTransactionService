package com.fintech.transaction.service;

import com.fintech.transaction.entity.FraudRule;
import com.fintech.transaction.exception.FraudDetectedException;
import com.fintech.transaction.repository.FraudRuleRepository;
import com.fintech.transaction.repository.TransactionRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
@Slf4j
public class FraudDetectionService {

    private final FraudRuleRepository fraudRuleRepository;
    private final TransactionRepository transactionRepository;

    /**
     * Evaluate all enabled fraud rules against the proposed transaction.
     * Throws FraudDetectedException if any rule is triggered.
     */
    @Transactional(readOnly = true)
    public void evaluate(UUID accountId, BigDecimal amount) {
        List<FraudRule> rules = fraudRuleRepository.findByEnabledTrue();

        LocalDateTime startOfDay = LocalDate.now().atStartOfDay();

        long dailyCount = transactionRepository.countDailyTransactions(accountId, startOfDay);
        BigDecimal dailyVolume = transactionRepository.sumDailyTransactionVolume(accountId, startOfDay);

        for (FraudRule rule : rules) {
            log.debug("Evaluating fraud rule [{}] for accountId={}, amount={}",
                    rule.getRuleName(), accountId, amount);

            // Rule: single transaction amount cap
            if (rule.getMaxAmountLimit() != null
                    && amount.compareTo(rule.getMaxAmountLimit()) > 0) {
                String msg = String.format(
                        "Fraud rule [%s] triggered: amount %.2f exceeds single-transaction limit %.2f",
                        rule.getRuleName(), amount, rule.getMaxAmountLimit());
                log.warn(msg);
                throw new FraudDetectedException(msg);
            }

            // Rule: daily transaction count cap
            if (rule.getMaxDailyTxnCount() != null
                    && dailyCount >= rule.getMaxDailyTxnCount()) {
                String msg = String.format(
                        "Fraud rule [%s] triggered: daily transaction count %d reached limit %d",
                        rule.getRuleName(), dailyCount, rule.getMaxDailyTxnCount());
                log.warn(msg);
                throw new FraudDetectedException(msg);
            }

            // Rule: daily volume cap
            if (rule.getMaxDailyTxnVolume() != null
                    && dailyVolume.add(amount).compareTo(rule.getMaxDailyTxnVolume()) > 0) {
                String msg = String.format(
                        "Fraud rule [%s] triggered: daily volume %.2f would exceed limit %.2f",
                        rule.getRuleName(), dailyVolume.add(amount), rule.getMaxDailyTxnVolume());
                log.warn(msg);
                throw new FraudDetectedException(msg);
            }
        }

        log.debug("All fraud rules passed for accountId={}", accountId);
    }
}
