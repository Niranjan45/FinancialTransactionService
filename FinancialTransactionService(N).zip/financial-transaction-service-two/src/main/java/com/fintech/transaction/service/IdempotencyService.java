package com.fintech.transaction.service;

import com.fintech.transaction.entity.IdempotencyRecord;
import com.fintech.transaction.repository.IdempotencyRecordRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.Optional;

@Service
@RequiredArgsConstructor
@Slf4j
public class IdempotencyService {

    private final IdempotencyRecordRepository idempotencyRepo;

    @Value("${idempotency.key.ttl-minutes:1440}")
    private int ttlMinutes;

    /**
     * Returns cached response if idempotency key was already processed,
     * otherwise empty.
     */
    @Transactional(readOnly = true)
    public Optional<String> findCachedResponse(String idempotencyKey) {
        return idempotencyRepo
                .findByIdempotencyKeyAndExpiresAtAfter(idempotencyKey, LocalDateTime.now())
                .map(IdempotencyRecord::getResponseBody);
    }

    /**
     * Store the response for a given idempotency key.
     */
    @Transactional
    public void storeResponse(String idempotencyKey, String responseBody, int statusCode) {
        IdempotencyRecord record = IdempotencyRecord.builder()
                .idempotencyKey(idempotencyKey)
                .responseBody(responseBody)
                .statusCode(statusCode)
                .expiresAt(LocalDateTime.now().plusMinutes(ttlMinutes))
                .build();
        idempotencyRepo.save(record);
        log.debug("Stored idempotency record for key={}", idempotencyKey);
    }

    @Transactional
    public int cleanupExpired() {
        int deleted = idempotencyRepo.deleteExpiredRecords(LocalDateTime.now());
        log.info("Cleaned up {} expired idempotency records", deleted);
        return deleted;
    }
}
