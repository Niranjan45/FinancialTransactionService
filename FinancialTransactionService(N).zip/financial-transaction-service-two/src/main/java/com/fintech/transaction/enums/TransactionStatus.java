package com.fintech.transaction.enums;

public enum TransactionStatus {
    INITIATED,
    PROCESSING,
    SUCCESS,
    FAILED,
    REVERSED
}
