package com.fintech.transaction.service;

import com.fintech.transaction.entity.Transaction;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@Service
@Slf4j
public class TransactionEventPublisher {

    /**
     * KafkaTemplate is injected only when Kafka is enabled (app.kafka.enabled=true).
     * Using Optional injection prevents a NoSuchBeanDefinitionException when Kafka
     * is not on the classpath or is disabled.
     */
    @Autowired(required = false)
    private KafkaTemplate<String, Object> kafkaTemplate;

    @Value("${kafka.topics.transaction-events:transaction-events}")
    private String topic;

    @Value("${app.kafka.enabled:false}")
    private boolean kafkaEnabled;

    public void publishTransactionEvent(Transaction transaction, String eventType) {
        if (!kafkaEnabled || kafkaTemplate == null) {
            log.debug("Kafka disabled — skipping event [{}] for txn={}",
                    eventType, transaction.getTransactionId());
            return;
        }

        try {
            Map<String, Object> event = new HashMap<>();
            event.put("transactionId", transaction.getTransactionId().toString());
            event.put("eventType",     eventType);
            event.put("status",        transaction.getStatus().name());
            event.put("amount",        transaction.getAmount());
            event.put("currency",      transaction.getCurrency());
            event.put("type",          transaction.getType().name());
            event.put("timestamp",     System.currentTimeMillis());

            if (transaction.getFromAccount() != null) {
                event.put("fromAccountId", transaction.getFromAccount().getAccountId().toString());
            }
            if (transaction.getToAccount() != null) {
                event.put("toAccountId", transaction.getToAccount().getAccountId().toString());
            }

            kafkaTemplate.send(topic, transaction.getTransactionId().toString(), event);
            log.info("Published Kafka event [{}] for txn={}", eventType, transaction.getTransactionId());

        } catch (Exception e) {
            // Non-blocking — Kafka failure must never roll back the core transaction
            log.error("Failed to publish Kafka event for txn={}: {}",
                    transaction.getTransactionId(), e.getMessage());
        }
    }
}
