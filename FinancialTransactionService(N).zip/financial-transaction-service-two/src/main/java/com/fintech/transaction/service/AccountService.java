package com.fintech.transaction.service;

import com.fintech.transaction.dto.request.CreateAccountRequest;
import com.fintech.transaction.dto.response.AccountResponse;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;

import java.util.UUID;

public interface AccountService {

    AccountResponse createAccount(CreateAccountRequest request);

    @Cacheable(value = "accounts", key = "#id")
    AccountResponse getAccountById(UUID id);

    @CacheEvict(value = "accounts", key = "#id")
    void evictAccountCache(UUID id);
}
