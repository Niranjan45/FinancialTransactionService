package com.fintech.transaction.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fintech.transaction.dto.request.CreditRequest;
import com.fintech.transaction.dto.request.DebitRequest;
import com.fintech.transaction.dto.request.TransactionFilterRequest;
import com.fintech.transaction.dto.request.TransferRequest;
import com.fintech.transaction.dto.response.MetricsResponse;
import com.fintech.transaction.dto.response.TransactionResponse;
import com.fintech.transaction.entity.Account;
import com.fintech.transaction.entity.Transaction;
import com.fintech.transaction.enums.AccountStatus;
import com.fintech.transaction.enums.AuditEventType;
import com.fintech.transaction.enums.TransactionStatus;
import com.fintech.transaction.enums.TransactionType;
import com.fintech.transaction.exception.*;
import com.fintech.transaction.repository.AccountRepository;
import com.fintech.transaction.repository.TransactionRepository;
import com.fintech.transaction.service.*;
import com.fintech.transaction.util.TransactionMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class TransactionServiceImpl implements TransactionService {

    private final TransactionRepository    transactionRepository;
    private final AccountRepository        accountRepository;
    private final FraudDetectionService    fraudService;
    private final AuditService             auditService;
    private final IdempotencyService       idempotencyService;
    private final TransactionEventPublisher eventPublisher;
    private final TransactionMapper        transactionMapper;
    private final ObjectMapper             objectMapper;
    private final AccountService           accountService;

    // ─────────────────────────────────────────────────────────────────────────
    // DEBIT
    // ─────────────────────────────────────────────────────────────────────────
    @Override
    @Transactional
    public TransactionResponse debit(DebitRequest request) {
        Optional<String> cached = idempotencyService.findCachedResponse(request.getIdempotencyKey());
        if (cached.isPresent()) {
            log.info("Idempotency hit for key={}", request.getIdempotencyKey());
            return deserialize(cached.get(), TransactionResponse.class);
        }

        Account account = getActiveAccount(request.getAccountId());
        fraudService.evaluate(account.getAccountId(), request.getAmount());

        if (!account.hasSufficientBalance(request.getAmount())) {
            throw new InsufficientBalanceException(
                    "Insufficient balance. Available: " + account.getBalance() +
                    ", Requested: " + request.getAmount());
        }

        Transaction txn = Transaction.builder()
                .idempotencyKey(request.getIdempotencyKey())
                .fromAccount(account)
                .amount(request.getAmount())
                .currency(request.getCurrency())
                .type(TransactionType.DEBIT)
                .status(TransactionStatus.PROCESSING)
                .description(request.getDescription())
                .build();
        txn = transactionRepository.save(txn);
        auditService.log(txn.getTransactionId(), AuditEventType.TRANSACTION_PROCESSING,
                "Debit processing started");

        // Deduct balance
        account.setBalance(account.getBalance().subtract(request.getAmount()));
        accountRepository.save(account);
        accountService.evictAccountCache(account.getAccountId());

        txn.setStatus(TransactionStatus.SUCCESS);
        txn = transactionRepository.save(txn);

        auditService.log(txn.getTransactionId(), AuditEventType.TRANSACTION_SUCCESS,
                "Debit of " + request.getAmount() + " " + request.getCurrency() + " successful");

        eventPublisher.publishTransactionEvent(txn, "DEBIT_SUCCESS");

        TransactionResponse response = transactionMapper.toResponse(txn);
        cacheIdempotencyResponse(request.getIdempotencyKey(), response);
        return response;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // CREDIT
    // ─────────────────────────────────────────────────────────────────────────
    @Override
    @Transactional
    public TransactionResponse credit(CreditRequest request) {
        Optional<String> cached = idempotencyService.findCachedResponse(request.getIdempotencyKey());
        if (cached.isPresent()) {
            log.info("Idempotency hit for key={}", request.getIdempotencyKey());
            return deserialize(cached.get(), TransactionResponse.class);
        }

        Account account = getActiveAccount(request.getAccountId());
        fraudService.evaluate(account.getAccountId(), request.getAmount());

        Transaction txn = Transaction.builder()
                .idempotencyKey(request.getIdempotencyKey())
                .toAccount(account)
                .amount(request.getAmount())
                .currency(request.getCurrency())
                .type(TransactionType.CREDIT)
                .status(TransactionStatus.PROCESSING)
                .description(request.getDescription())
                .build();
        txn = transactionRepository.save(txn);
        auditService.log(txn.getTransactionId(), AuditEventType.TRANSACTION_PROCESSING,
                "Credit processing started");

        account.setBalance(account.getBalance().add(request.getAmount()));
        accountRepository.save(account);
        accountService.evictAccountCache(account.getAccountId());

        txn.setStatus(TransactionStatus.SUCCESS);
        txn = transactionRepository.save(txn);

        auditService.log(txn.getTransactionId(), AuditEventType.TRANSACTION_SUCCESS,
                "Credit of " + request.getAmount() + " " + request.getCurrency() + " successful");

        eventPublisher.publishTransactionEvent(txn, "CREDIT_SUCCESS");

        TransactionResponse response = transactionMapper.toResponse(txn);
        cacheIdempotencyResponse(request.getIdempotencyKey(), response);
        return response;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // TRANSFER
    // ─────────────────────────────────────────────────────────────────────────
    @Override
    @Transactional
    public TransactionResponse transfer(TransferRequest request) {
        if (request.getFromAccountId().equals(request.getToAccountId())) {
            throw new IllegalArgumentException("Source and destination accounts must be different");
        }

        Optional<String> cached = idempotencyService.findCachedResponse(request.getIdempotencyKey());
        if (cached.isPresent()) {
            log.info("Idempotency hit for key={}", request.getIdempotencyKey());
            return deserialize(cached.get(), TransactionResponse.class);
        }

        // Lock accounts in a consistent order to prevent deadlocks
        List<UUID> sorted = Arrays.asList(request.getFromAccountId(), request.getToAccountId());
        Collections.sort(sorted);
        Account first  = getActiveAccount(sorted.get(0));
        Account second = getActiveAccount(sorted.get(1));

        Account fromAccount = first.getAccountId().equals(request.getFromAccountId()) ? first : second;
        Account toAccount   = first.getAccountId().equals(request.getToAccountId())   ? first : second;

        fraudService.evaluate(fromAccount.getAccountId(), request.getAmount());

        if (!fromAccount.hasSufficientBalance(request.getAmount())) {
            throw new InsufficientBalanceException(
                    "Insufficient balance. Available: " + fromAccount.getBalance() +
                    ", Requested: " + request.getAmount());
        }

        Transaction txn = Transaction.builder()
                .idempotencyKey(request.getIdempotencyKey())
                .fromAccount(fromAccount)
                .toAccount(toAccount)
                .amount(request.getAmount())
                .currency(request.getCurrency())
                .type(TransactionType.TRANSFER)
                .status(TransactionStatus.PROCESSING)
                .description(request.getDescription())
                .build();
        txn = transactionRepository.save(txn);
        auditService.log(txn.getTransactionId(), AuditEventType.TRANSACTION_PROCESSING,
                "Transfer processing started");

        fromAccount.setBalance(fromAccount.getBalance().subtract(request.getAmount()));
        toAccount.setBalance(toAccount.getBalance().add(request.getAmount()));
        accountRepository.save(fromAccount);
        accountRepository.save(toAccount);
        accountService.evictAccountCache(fromAccount.getAccountId());
        accountService.evictAccountCache(toAccount.getAccountId());

        txn.setStatus(TransactionStatus.SUCCESS);
        txn = transactionRepository.save(txn);

        auditService.log(txn.getTransactionId(), AuditEventType.TRANSACTION_SUCCESS,
                String.format("Transfer of %s %s from %s to %s successful",
                        request.getAmount(), request.getCurrency(),
                        fromAccount.getAccountId(), toAccount.getAccountId()));

        eventPublisher.publishTransactionEvent(txn, "TRANSFER_SUCCESS");

        TransactionResponse response = transactionMapper.toResponse(txn);
        cacheIdempotencyResponse(request.getIdempotencyKey(), response);
        return response;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // QUERY
    // ─────────────────────────────────────────────────────────────────────────
    @Override
    @Transactional(readOnly = true)
    public TransactionResponse getTransaction(UUID transactionId) {
        Transaction txn = transactionRepository.findById(transactionId)
                .orElseThrow(() -> new TransactionNotFoundException(
                        "Transaction not found: " + transactionId));
        return transactionMapper.toResponse(txn);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<TransactionResponse> listTransactions(TransactionFilterRequest filter) {
        Sort sort = filter.getSortDir().equalsIgnoreCase("asc")
                ? Sort.by(filter.getSortBy()).ascending()
                : Sort.by(filter.getSortBy()).descending();
        Pageable pageable = PageRequest.of(filter.getPage(), filter.getSize(), sort);

        return transactionRepository.findAllWithFilters(
                filter.getAccountId(),
                filter.getStatus(),
                filter.getType(),
                filter.getFrom(),
                filter.getTo(),
                pageable
        ).map(transactionMapper::toResponse);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // METRICS
    // ─────────────────────────────────────────────────────────────────────────
    @Override
    @Transactional(readOnly = true)
    public MetricsResponse getMetrics() {
        List<Object[]> statusCounts = transactionRepository.countByStatus();
        Map<String, Long> byStatus = statusCounts.stream()
                .collect(Collectors.toMap(
                        row -> row[0].toString(),
                        row -> (Long) row[1]));

        long total = byStatus.values().stream().mapToLong(Long::longValue).sum();
        BigDecimal volume = transactionRepository.totalSuccessfulVolume();

        long totalAccounts  = accountRepository.count();
        long activeAccounts = accountRepository.countByStatus(AccountStatus.ACTIVE);

        return MetricsResponse.builder()
                .totalTransactions(total)
                .transactionsByStatus(byStatus)
                .totalSuccessfulVolume(volume)
                .totalAccounts(totalAccounts)
                .activeAccounts(activeAccounts)
                .build();
    }

    // ─────────────────────────────────────────────────────────────────────────
    // HELPERS
    // ─────────────────────────────────────────────────────────────────────────
    private Account getActiveAccount(UUID accountId) {
        Account account = accountRepository.findByIdWithLock(accountId)
                .orElseThrow(() -> new AccountNotFoundException("Account not found: " + accountId));
        if (!account.isActive()) {
            throw new AccountInactiveException(
                    "Account " + accountId + " is not active. Status: " + account.getStatus());
        }
        return account;
    }

    private void cacheIdempotencyResponse(String key, Object response) {
        try {
            String json = objectMapper.writeValueAsString(response);
            idempotencyService.storeResponse(key, json, 200);
        } catch (JsonProcessingException e) {
            log.warn("Failed to cache idempotency response for key={}: {}", key, e.getMessage());
        }
    }

    private <T> T deserialize(String json, Class<T> clazz) {
        try {
            return objectMapper.readValue(json, clazz);
        } catch (JsonProcessingException e) {
            log.error("Failed to deserialize cached idempotency response: {}", e.getMessage());
            throw new RuntimeException("Failed to process cached response", e);
        }
    }
}
