package com.fintech.transaction.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Table(name = "fraud_rules")
@Getter @Setter
@NoArgsConstructor @AllArgsConstructor
@Builder
public class FraudRule {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(name = "rule_id", updatable = false, nullable = false)
    private UUID ruleId;

    @Column(name = "rule_name", nullable = false, unique = true, length = 100)
    private String ruleName;

    @Column(name = "max_amount_limit", precision = 19, scale = 4)
    private BigDecimal maxAmountLimit;

    @Column(name = "min_amount_limit", precision = 19, scale = 4)
    private BigDecimal minAmountLimit;

    @Column(name = "max_daily_txn_count")
    private Integer maxDailyTxnCount;

    @Column(name = "max_daily_txn_volume", precision = 19, scale = 4)
    private BigDecimal maxDailyTxnVolume;

    @Column(name = "enabled", nullable = false)
    @Builder.Default
    private Boolean enabled = true;

    @CreationTimestamp
    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @UpdateTimestamp
    @Column(name = "updated_at", nullable = false)
    private LocalDateTime updatedAt;
}
