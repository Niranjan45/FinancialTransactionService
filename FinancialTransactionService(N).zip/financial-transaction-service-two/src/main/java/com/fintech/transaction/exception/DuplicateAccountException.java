package com.fintech.transaction.exception;
public class DuplicateAccountException extends RuntimeException {
    public DuplicateAccountException(String message) { super(message); }
}
