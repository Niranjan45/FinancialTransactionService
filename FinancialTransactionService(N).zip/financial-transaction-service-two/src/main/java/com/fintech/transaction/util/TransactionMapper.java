package com.fintech.transaction.util;

import com.fintech.transaction.dto.response.TransactionResponse;
import com.fintech.transaction.entity.Transaction;
import org.springframework.stereotype.Component;

@Component
public class TransactionMapper {

    public TransactionResponse toResponse(Transaction txn) {
        if (txn == null) return null;
        return TransactionResponse.builder()
                .transactionId(txn.getTransactionId())
                .idempotencyKey(txn.getIdempotencyKey())
                .fromAccountId(txn.getFromAccount() != null
                        ? txn.getFromAccount().getAccountId() : null)
                .toAccountId(txn.getToAccount() != null
                        ? txn.getToAccount().getAccountId() : null)
                .amount(txn.getAmount())
                .currency(txn.getCurrency())
                .type(txn.getType())
                .status(txn.getStatus())
                .description(txn.getDescription())
                .failureReason(txn.getFailureReason())
                .retryCount(txn.getRetryCount())
                .createdAt(txn.getCreatedAt())
                .updatedAt(txn.getUpdatedAt())
                .build();
    }
}
